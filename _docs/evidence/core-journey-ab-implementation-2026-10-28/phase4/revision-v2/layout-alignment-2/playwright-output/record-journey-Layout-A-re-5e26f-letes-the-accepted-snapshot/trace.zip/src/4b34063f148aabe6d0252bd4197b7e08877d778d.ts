import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { test, expect, type Page } from '@playwright/test';

const evidenceDirectory = path.resolve(
  process.cwd(), '..', '_docs', 'evidence', 'core-journey-ab-implementation-2026-10-28',
  ...(process.env.DUBBED_CORE_EVIDENCE_RUN ?? 'phase3').split(/[\\/]+/),
);

async function setRecordLocale(page: Page, locale: 'en' | 'ru') {
  const url = new URL(page.url());
  url.searchParams.set('locale', locale);
  await page.goto(`${url.pathname}${url.search}`);
}

async function instrumentNativeMedia(page: Page) {
  await page.addInitScript(() => {
    const target = window as Window & {
      __nativeRecordEvidence?: { getUserMediaCalls: number; recorderStarts: number };
      __lockEvidence?: { requests: string[]; callbacks: Array<'acquired' | 'null'> };
      __denyMicrophone?: boolean;
    };
    target.__nativeRecordEvidence = { getUserMediaCalls: 0, recorderStarts: 0 };
    try {
      const savedEvidence = sessionStorage.getItem('__dubbed_native_record_evidence_v1');
      if (savedEvidence) target.__nativeRecordEvidence = JSON.parse(savedEvidence) as NonNullable<typeof target.__nativeRecordEvidence>;
    } catch { /* Evidence storage is best-effort; browser behavior remains authoritative. */ }
    const persistNativeEvidence = () => {
      try { sessionStorage.setItem('__dubbed_native_record_evidence_v1', JSON.stringify(target.__nativeRecordEvidence)); }
      catch { /* Keep capture behavior independent of evidence storage. */ }
    };
    target.__lockEvidence = { requests: [], callbacks: [] };
    const lockManager = navigator.locks;
    const originalRequest = lockManager.request.bind(lockManager);
    Object.defineProperty(lockManager, 'request', {
      configurable: true,
      value: (name: string, options: LockOptions, callback: (lock: Lock | null) => Promise<unknown> | unknown) => {
        target.__lockEvidence!.requests.push(name);
        return originalRequest(name, options, (lock) => {
          target.__lockEvidence!.callbacks.push(lock ? 'acquired' : 'null');
          return callback(lock);
        });
      },
    });
    const mediaDevices = navigator.mediaDevices;
    if (mediaDevices) {
      const getUserMedia = mediaDevices.getUserMedia.bind(mediaDevices);
      mediaDevices.getUserMedia = (...args: Parameters<MediaDevices['getUserMedia']>) => {
        target.__nativeRecordEvidence!.getUserMediaCalls += 1;
        persistNativeEvidence();
        if (target.__denyMicrophone) return Promise.reject(new DOMException('Microphone permission denied in the test harness.', 'NotAllowedError'));
        return getUserMedia(...args);
      };
    }
    if (window.MediaRecorder) {
      const start = MediaRecorder.prototype.start;
      MediaRecorder.prototype.start = function (...args: Parameters<MediaRecorder['start']>) {
        target.__nativeRecordEvidence!.recorderStarts += 1;
        persistNativeEvidence();
        return start.apply(this, args);
      };
    }
  });
}

async function evidenceCounters(page: Page) {
  return page.evaluate(() => (window as unknown as Window & { __nativeRecordEvidence: { getUserMediaCalls: number; recorderStarts: number } }).__nativeRecordEvidence);
}

async function installStoreFailure(page: Page, mode: 'lost-acknowledgement' | 'known-failure') {
  await page.evaluate((faultMode) => {
    type ProjectStore = {
      saveCandidate(request: { operationId: string; capture: { blob: Blob } }): Promise<unknown>;
      lookupOperation(...args: unknown[]): Promise<unknown>;
    };
    type Fiber = { child?: unknown; sibling?: unknown; memoizedProps?: unknown };
    const root = document.getElementById('root') as (HTMLElement & Record<string, unknown>) | null;
    if (!root) throw new Error('The React root is unavailable.');
    const rootKey = Object.keys(root).find((key) => key.startsWith('__reactContainer$'));
    if (!rootKey) throw new Error('The React root fiber is unavailable.');
    const pending: unknown[] = [root[rootKey]];
    let store: ProjectStore | null = null;
    while (pending.length > 0) {
      const fiber = pending.pop() as Fiber | null;
      if (!fiber) continue;
      const props = fiber.memoizedProps as { services?: { projects?: ProjectStore } } | null;
      if (props?.services?.projects) store = props.services.projects;
      if (fiber.child) pending.push(fiber.child);
      if (fiber.sibling) pending.push(fiber.sibling);
    }
    if (!store) throw new Error('The active typed ProjectPort was not found in the services provider.');
    const originalSave = store.saveCandidate.bind(store);
    const originalLookup = store.lookupOperation.bind(store);
    const trace = { saveCalls: 0, lookupCalls: 0, operationIds: [] as string[], blobSizes: [] as number[], retrySameBlob: null as boolean | null };
    (window as Window & { __storeFailureTrace?: typeof trace }).__storeFailureTrace = trace;
    let firstKnownFailure = true;
    let failedBlob: Blob | null = null;
    store.saveCandidate = async (request) => {
      trace.saveCalls += 1;
      trace.operationIds.push(request.operationId);
      trace.blobSizes.push(request.capture.blob.size);
      if (faultMode === 'known-failure' && firstKnownFailure) {
        firstKnownFailure = false;
        failedBlob = request.capture.blob;
        throw new DOMException('Synthetic known quota failure before a write was sent.', 'QuotaExceededError');
      }
      if (faultMode === 'known-failure' && failedBlob) trace.retrySameBlob = failedBlob === request.capture.blob;
      const committed = await originalSave(request);
      return faultMode === 'lost-acknowledgement'
        ? { kind: 'unknown', operationId: request.operationId, reason: 'Test harness withheld the successful acknowledgement.' }
        : committed;
    };
    store.lookupOperation = async (...args) => {
      trace.lookupCalls += 1;
      if (faultMode === 'lost-acknowledgement' && trace.lookupCalls === 1) {
        return { kind: 'pending', operationId: String(args[1]) };
      }
      return originalLookup(...args);
    };
  }, mode);
}

async function installAcceptanceFailure(page: Page) {
  await page.evaluate(async () => {
    const originalTransaction = IDBDatabase.prototype.transaction;
    const trace = { calls: 0, stores: [] as string[], restore: () => undefined };
    (window as Window & { __acceptFailureTrace?: typeof trace }).__acceptFailureTrace = trace;
    IDBDatabase.prototype.transaction = function (storeNames, mode, options) {
      const stores = typeof storeNames === 'string' ? [storeNames] : [...storeNames];
      if (trace.calls === 0 && mode === 'readwrite' && stores.includes('operations')) {
        trace.calls += 1;
        trace.stores = stores;
        throw new DOMException('Synthetic known acceptance write failure.', 'QuotaExceededError');
      }
      return originalTransaction.call(this, storeNames, mode, options);
    };
    trace.restore = () => { IDBDatabase.prototype.transaction = originalTransaction; };
  });
}

async function installNextOperationWriteFailure(page: Page) {
  await page.evaluate(() => {
    const original = IDBDatabase.prototype.transaction;
    const trace = { calls: 0, stores: [] as string[] };
    const target = window as Window & {
      __operationWriteFailure?: typeof trace;
      __restoreOperationWriteFailure?: () => void;
    };
    target.__operationWriteFailure = trace;
    IDBDatabase.prototype.transaction = function (storeNames, mode, options) {
      const stores = typeof storeNames === 'string' ? [storeNames] : [...storeNames];
      if (trace.calls === 0 && mode === 'readwrite' && stores.includes('operations')) {
        trace.calls += 1;
        trace.stores = stores;
        throw new DOMException('Synthetic known candidate write failure.', 'QuotaExceededError');
      }
      return original.call(this, storeNames, mode, options);
    };
    target.__restoreOperationWriteFailure = () => { IDBDatabase.prototype.transaction = original; };
  });
}

async function traceNextNativeBlobDigest(page: Page) {
  await page.evaluate(() => {
    const trace = { captures: 0, byteSize: 0, mimeType: '', sha256: null as string | null };
    (window as Window & { __nativeBlobDigestTrace?: typeof trace }).__nativeBlobDigestTrace = trace;
    const prototype = MediaRecorder.prototype;
    const start = prototype.start;
    prototype.start = function (...args: Parameters<MediaRecorder['start']>) {
      const chunks: BlobPart[] = [];
      this.addEventListener('dataavailable', (event) => { if (event.data.size > 0) chunks.push(event.data); });
      this.addEventListener('stop', () => {
        const blob = new Blob(chunks, { type: this.mimeType });
        trace.captures += 1;
        trace.byteSize = blob.size;
        trace.mimeType = blob.type;
        void blob.arrayBuffer().then((bytes) => crypto.subtle.digest('SHA-256', bytes)).then((digest) => {
          trace.sha256 = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
        });
      }, { once: true });
      return start.apply(this, args);
    };
  });
}

async function storeFailureTrace(page: Page) {
  return page.evaluate(() => (window as unknown as Window & {
    __storeFailureTrace: { saveCalls: number; lookupCalls: number; operationIds: string[]; blobSizes: number[]; retrySameBlob: boolean | null };
  }).__storeFailureTrace);
}

async function readIndexedDb(page: Page) {
  return page.evaluate(async () => {
    const database = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('dubbed-core-local-v1');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const read = <T>(storeName: string, key?: IDBValidKey) => new Promise<T>((resolve, reject) => {
      const transaction = database.transaction(storeName, 'readonly');
      const request = key === undefined ? transaction.objectStore(storeName).getAll() : transaction.objectStore(storeName).get(key);
      request.onsuccess = () => resolve(request.result as T);
      request.onerror = () => reject(request.error);
    });
    const project = await read<Record<string, unknown>>('projects', 'sintel-prepared');
    const media = await read<Array<Record<string, unknown>>>('media');
    const operations = await read<Array<Record<string, unknown>>>('operations');
    const snapshots = await read<Array<Record<string, unknown>>>('snapshots');
    database.close();
    return {
      project: project ? {
        revision: project.revision,
        draftCandidateByTurn: project.draftCandidateByTurn,
        acceptedByTurn: project.acceptedByTurn,
        initialResultSnapshotId: project.initialResultSnapshotId,
        latestResultSnapshotId: project.latestResultSnapshotId,
        tombstonedAt: project.tombstonedAt,
      } : null,
      media: media.map((candidate) => ({
        id: candidate.id,
        purpose: candidate.purpose,
        turnId: candidate.turnId,
        byteSize: candidate.byteSize,
        sha256: candidate.sha256,
        mimeType: candidate.mimeType,
        endReason: candidate.endReason,
        probe: candidate.probe,
        blobSize: (candidate.blob as Blob | undefined)?.size ?? null,
      })),
      operations: operations.map((operation) => ({
        id: operation.id,
        kind: operation.kind,
        state: operation.state,
        turnId: operation.turnId,
        projectRevision: operation.projectRevision,
        snapshotId: operation.snapshotId,
        navigationIntent: operation.navigationIntent,
        navigationCompleted: operation.navigationCompleted,
        sha256: operation.sha256,
      })),
      snapshots: snapshots.map((snapshot) => ({
        id: snapshot.id,
        projectRevision: snapshot.projectRevision,
        contentSha256: snapshot.contentSha256,
        authorization: snapshot.authorization,
        takes: snapshot.takes,
      })),
    };
  });
}

test('reconciles a lost save acknowledgement with the original operation before accepting the candidate', async ({ page, browser }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A');
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  await installStoreFailure(page, 'lost-acknowledgement');

  await page.getByRole('button', { name: 'Record', exact: true }).click();
  await expect.poll(async () => (await evidenceCounters(page)).recorderStarts).toBe(1);
  await expect(page.locator('.record-panel .notice')).toContainText('The save outcome is unknown. Check this same operation before trying another recording.', { timeout: 15_000 });
  await expect(page.getByRole('button', { name: 'Check saved status', exact: true })).toBeEnabled();
  const unknownTrace = await storeFailureTrace(page);
  expect(unknownTrace.saveCalls).toBe(1);
  expect(unknownTrace.lookupCalls).toBe(1);
  expect(unknownTrace.operationIds).toHaveLength(1);

  await page.getByRole('button', { name: 'Check saved status', exact: true }).click();
  const stored = await waitForSavedCandidate(page, 'A');
  const resolvedTrace = await storeFailureTrace(page);
  expect(resolvedTrace.saveCalls).toBe(1);
  expect(resolvedTrace.lookupCalls).toBe(2);
  expect(resolvedTrace.operationIds).toEqual([unknownTrace.operationIds[0]]);
  const database = await readIndexedDb(page);
  const journalEntry = database.operations.find((operation) => operation.id === unknownTrace.operationIds[0]);
  expect(journalEntry?.state).toBe('committed');
  expect(journalEntry?.sha256).toBe(stored?.sha256);
  await writeFile(path.join(evidenceDirectory, 'lost-save-ack-browser-evidence.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    scenario: 'The mock store committed the Blob but withheld its acknowledgement; first status lookup reported pending; explicit check read the committed receipt.',
    physicalMicrophone: false,
    nativeApiEvidence: await evidenceCounters(page),
    trace: resolvedTrace,
    journalEntry,
    savedCandidate: stored,
  }, null, 2), 'utf8');
});

test('keeps an accepted take intact after a known save failure and retries the exact captured Blob', async ({ page, browser }) => {
  test.setTimeout(45_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A');
  await recordCurrentWindow(page, 'A');
  await page.getByRole('button', { name: 'Next', exact: true }).click();
  await expect(page).toHaveURL(/turn=sintel-turn-2/);
  await page.getByRole('button', { name: 'Previous', exact: true }).click();
  await expect(page).toHaveURL(/turn=sintel-turn-1/);
  const beforeFailure = await readIndexedDb(page);
  const acceptedBefore = (beforeFailure.project?.acceptedByTurn as Record<string, string>)['sintel-turn-1'];
  expect(acceptedBefore).toBeTruthy();

  await installNextOperationWriteFailure(page);
  await traceNextNativeBlobDigest(page);
  await page.getByRole('button', { name: 'Record', exact: true }).click();
  await expect.poll(async () => (await evidenceCounters(page)).recorderStarts).toBe(2);
  await expect(page.locator('.record-panel .notice')).toContainText('The candidate could not be saved. The current recording and previously accepted take remain available here.', { timeout: 15_000 });
  await expect(page.getByRole('button', { name: 'Retry save', exact: true })).toBeEnabled();
  const recoveryToast = page.locator('.recovery-toast');
  await expect(recoveryToast).toBeVisible();
  expect(await recoveryToast.getByRole('button').count()).toBe(0);
  const toastStyle = await recoveryToast.evaluate((element) => {
    const style = getComputedStyle(element);
    const bounds = element.getBoundingClientRect();
    const icon = element.querySelector('svg');
    return {
      background: style.backgroundColor,
      borderRadius: style.borderRadius,
      bottom: style.bottom,
      width: bounds.width,
      padding: style.padding,
      boxShadow: style.boxShadow,
      iconColor: icon ? getComputedStyle(icon).color : null,
      titleFont: getComputedStyle(element.querySelector('.recovery-toast__title')!).font,
      bodyFont: getComputedStyle(element.querySelector('.recovery-toast__body')!).font,
    };
  });
  expect(toastStyle.background).toBe('rgb(32, 32, 32)');
  expect(toastStyle.borderRadius).toBe('10px');
  expect(toastStyle.bottom).toBe('16px');
  expect(toastStyle.width).toBeLessThanOrEqual(520);
  expect(toastStyle.padding).toBe('14px 16px');
  expect(toastStyle.iconColor).toBe('rgb(255, 156, 159)');
  await page.screenshot({ path: path.join(evidenceDirectory, 'known-save-failure-recovery-toast.png') });
  const failedTrace = await page.evaluate(() => (window as unknown as Window & { __operationWriteFailure: { calls: number; stores: string[] } }).__operationWriteFailure);
  expect(failedTrace.calls).toBe(1);
  expect(failedTrace.stores).toContain('operations');
  await page.evaluate(() => (window as unknown as Window & { __restoreOperationWriteFailure: () => void }).__restoreOperationWriteFailure());
  const focusBeforeExpiry = await page.evaluate(() => ({
    recoveryFocused: document.activeElement?.matches('[data-recovery-action="retry-save"]') ?? false,
    scrollY: window.scrollY,
  }));
  expect(focusBeforeExpiry.recoveryFocused).toBe(true);
  await expect(recoveryToast).toHaveCount(0, { timeout: 10_000 });
  expect(await page.locator('[data-recovery-action="retry-save"]').evaluate((element) => element === document.activeElement)).toBe(true);
  expect(await page.evaluate(() => window.scrollY)).toBe(focusBeforeExpiry.scrollY);
  const afterFailure = await readIndexedDb(page);
  expect((afterFailure.project?.acceptedByTurn as Record<string, string>)['sintel-turn-1']).toBe(acceptedBefore);
  expect(afterFailure.media.filter((stored) => stored.purpose === 'recording' && stored.id !== acceptedBefore)).toHaveLength(0);

  await page.getByRole('button', { name: 'Retry save', exact: true }).click();
  const saved = await waitForSavedCandidate(page, 'A');
  await expect.poll(async () => page.evaluate(() => (window as unknown as Window & {
    __nativeBlobDigestTrace: { captures: number; byteSize: number; mimeType: string; sha256: string | null };
  }).__nativeBlobDigestTrace.sha256), { timeout: 5_000 }).toBe(saved?.sha256);
  const recoveredTrace = await page.evaluate(() => (window as unknown as Window & {
    __nativeBlobDigestTrace: { captures: number; byteSize: number; mimeType: string; sha256: string | null };
  }).__nativeBlobDigestTrace);
  expect(recoveredTrace.captures).toBe(1);
  expect(recoveredTrace.byteSize).toBe(saved?.blobSize);
  expect(recoveredTrace.mimeType).toBe(saved?.mimeType);
  const afterRetry = await readIndexedDb(page);
  expect((afterRetry.project?.acceptedByTurn as Record<string, string>)['sintel-turn-1']).toBe(acceptedBefore);
  expect((afterRetry.project?.draftCandidateByTurn as Record<string, string>)['sintel-turn-1']).toBe(saved?.id);
  await writeFile(path.join(evidenceDirectory, 'known-save-failure-browser-evidence.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    scenario: 'First accepted take preserved after a known pre-write quota failure. Retry saved the exact captured Blob without re-recording.',
    physicalMicrophone: false,
    nativeApiEvidence: await evidenceCounters(page),
    acceptedCandidateBeforeFailure: acceptedBefore,
    failedAttempt: failedTrace,
    recoveryToast: toastStyle,
    capturedBlobBeforePersistence: recoveredTrace,
    retry: recoveredTrace,
    finalProject: afterRetry.project,
    retriedCandidate: saved,
  }, null, 2), 'utf8');
});

test('failed guarded Exit keeps the original intent, focuses Retry, and restores Exit after retry and boundary return', async ({ page, browser }) => {
  test.setTimeout(45_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A&locale=en');
  const candidate = await (async () => {
    await expect.poll(() => page.locator('video').evaluate((video: HTMLVideoElement) =>
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0), { timeout: 15_000 }).toBe(true);
    await recordCurrentWindow(page, 'A');
    return waitForSavedCandidate(page, 'A');
  })();
  await installAcceptanceFailure(page);
  await page.getByRole('button', { name: 'Exit', exact: true }).click();
  const guard = page.getByRole('dialog');
  await expect(guard).toBeVisible();
  await guard.getByRole('button', { name: 'Save and leave', exact: true }).click();
  await expect(guard.getByRole('button', { name: 'Retry accept and leave', exact: true })).toBeVisible();
  const retry = guard.locator('[data-recovery-action="retry-guard"]');
  await expect(retry).toBeFocused();
  const failed = await readIndexedDb(page);
  expect(failed.project?.draftCandidateByTurn).toMatchObject({ 'sintel-turn-1': candidate?.id });
  expect(Object.values(failed.project?.acceptedByTurn as Record<string, string> ?? {})).toHaveLength(0);
  const acceptanceFailure = await page.evaluate(() => (window as unknown as Window & { __acceptFailureTrace: { calls: number; stores: string[]; restore: () => void } }).__acceptFailureTrace);
  expect(acceptanceFailure.calls).toBe(1);
  expect(acceptanceFailure.stores).toContain('operations');
  await page.evaluate(() => (window as unknown as Window & { __acceptFailureTrace: { restore: () => void } }).__acceptFailureTrace.restore());
  await page.screenshot({ path: path.join(evidenceDirectory, 'guarded-exit-known-acceptance-failure.png') });

  const beforeToastExpiry = await page.evaluate(() => ({
    focusedRetry: document.activeElement?.matches('[data-recovery-action="retry-guard"]') ?? false,
    scrollY: window.scrollY,
  }));
  expect(beforeToastExpiry.focusedRetry).toBe(true);
  await expect(page.locator('.recovery-toast')).toHaveCount(0, { timeout: 10_000 });
  await expect(retry).toBeFocused();
  const retryFocusedAfterToastExpiry = await retry.evaluate((element) => element === document.activeElement);
  expect(retryFocusedAfterToastExpiry).toBe(true);
  expect(await page.evaluate(() => window.scrollY)).toBe(beforeToastExpiry.scrollY);
  await retry.click();
  await expect(page).toHaveURL(/\/projects\?.*returnFocus=exit/);
  await page.screenshot({ path: path.join(evidenceDirectory, 'guarded-exit-success-boundary.png'), fullPage: true });
  await page.getByTestId('return-to-saved-record').click();
  await expect(page).toHaveURL(/returnFocus=exit/);
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  await expect(page.locator('[data-logical-focus="exit"]')).toBeFocused();
  const accepted = await readIndexedDb(page);
  expect(accepted.project?.acceptedByTurn).toMatchObject({ 'sintel-turn-1': candidate?.id });
  const successfulAcceptOperations = accepted.operations.filter((operation) => operation.kind === 'accept-candidate' && operation.state === 'committed');
  expect(successfulAcceptOperations).toHaveLength(1);
  await writeFile(path.join(evidenceDirectory, 'guarded-exit-retry-focus-evidence.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    nativeInput: 'Chrome browser fake audio input; not a physical microphone',
    candidateId: candidate?.id,
    acceptedBeforeRetry: failed.project?.acceptedByTurn,
    acceptedAfterRetry: accepted.project?.acceptedByTurn,
    failureTrace: acceptanceFailure,
    successfulAcceptOperations,
    focusBeforeToastExpiry: beforeToastExpiry,
    retryFocusedAfterToastExpiry,
    boundaryReturnFocusedExit: await page.locator('[data-logical-focus="exit"]').evaluate((element) => element === document.activeElement),
  }, null, 2), 'utf8');
});

async function waitForSavedCandidate(page: Page, layout: 'A' | 'B') {
  const notice = layout === 'A' ? page.locator('.record-panel .notice') : page.locator('.record-status--b .notice');
  await expect(notice).toContainText('Take saved as a recoverable candidate. It has not been accepted.', { timeout: 15_000 });
  await expect(page.locator('.waveform-take')).toHaveCount(1);
  const database = await readIndexedDb(page);
  const currentTurnId = new URL(page.url()).searchParams.get('turn') ?? 'sintel-turn-1';
  const draftByTurn = database.project?.draftCandidateByTurn as Record<string, string> | undefined;
  const current = database.media.find((candidate) => candidate.id === draftByTurn?.[currentTurnId]);
  expect(current?.blobSize).toBeGreaterThan(0);
  expect(current?.blobSize).toBe(current?.byteSize);
  expect(current?.sha256).toMatch(/^[a-f0-9]{64}$/);
  expect((current?.probe as { byteSize?: number }).byteSize).toBe(current?.blobSize);
  return current;
}

async function recordCurrentWindow(page: Page, layout: 'A' | 'B') {
  const recordButton = page.getByRole('button', { name: 'Record', exact: true });
  await expect(recordButton).toBeEnabled();
  await recordButton.click();
  await expect.poll(async () => (await evidenceCounters(page)).recorderStarts).toBeGreaterThan(0);
  const startedAt = await page.locator('video').evaluate((video: HTMLVideoElement) => video.currentTime);
  await page.waitForTimeout(400);
  const movedTo = await page.locator('video').evaluate((video: HTMLVideoElement) => video.currentTime);
  expect(movedTo).toBeGreaterThan(startedAt);
  await expect(page.getByRole('button', { name: /Countdown|Stop recording|Pause recording/i })).toHaveCount(0);
  await waitForSavedCandidate(page, layout);
}

test.beforeAll(async () => mkdir(evidenceDirectory, { recursive: true }));

test('Exit returns through the guarded Projects boundary and restores focus to the logical Exit control', async ({ page }) => {
  await page.goto('/projects/sintel-prepared/record?layout=A&locale=en');
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  await expect(page.locator('.record-header .lucide-log-out')).toHaveCount(1);
  await page.getByRole('button', { name: 'Exit', exact: true }).click();
  await expect(page).toHaveURL(/\/projects\?/);
  await page.getByTestId('return-to-saved-record').click();
  await expect(page).toHaveURL(/returnFocus=exit/);
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  await expect(page.locator('[data-logical-focus="exit"]')).toBeFocused();
  await page.screenshot({ path: path.join(evidenceDirectory, 'exit-boundary-return-focus.png') });
});

test('delayed source playback keeps the recorder idle until the prepared window actually starts', async ({ page, browser }) => {
  test.setTimeout(45_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A&locale=en');
  await expect.poll(() => page.locator('video').evaluate((video: HTMLVideoElement) =>
    video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0), { timeout: 15_000 }).toBe(true);
  const preparedWindow = await page.evaluate(async () => {
    const database = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('dubbed-core-local-v1');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const project = await new Promise<{ windows: Array<{ id: string; startMs: number; endMs: number }> }>((resolve, reject) => {
      const request = database.transaction('projects', 'readonly').objectStore('projects').get('sintel-prepared');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    database.close();
    const selected = project.windows.find((window) => window.id === 'sintel-turn-1');
    if (!selected) throw new Error('Prepared turn 1 is missing its source window.');
    return selected;
  });
  await page.locator('video').evaluate((element) => {
    const video = element as HTMLVideoElement;
    const trace = {
      requestedAt: null as number | null,
      nativePlayAt: null as number | null,
      playingAt: null as number | null,
      playingVideoTime: null as number | null,
      recorderStartAt: null as number | null,
      recorderStartVideoTime: null as number | null,
      recorderStopAt: null as number | null,
      recorderStopVideoTime: null as number | null,
    };
    (window as Window & { __delayedCaptureTrace?: typeof trace }).__delayedCaptureTrace = trace;
    const nativePlay = video.play.bind(video);
    Object.defineProperty(video, 'play', {
      configurable: true,
      value: () => {
        trace.requestedAt = performance.now();
        return new Promise<void>((resolve, reject) => {
          window.setTimeout(() => {
            trace.nativePlayAt = performance.now();
            nativePlay().then(resolve, reject);
          }, 1_200);
        });
      },
    });
    video.addEventListener('playing', () => {
      trace.playingAt = performance.now();
      trace.playingVideoTime = video.currentTime;
    }, { once: true });
    const start = MediaRecorder.prototype.start;
    MediaRecorder.prototype.start = function (...args: Parameters<MediaRecorder['start']>) {
      trace.recorderStartAt = performance.now();
      trace.recorderStartVideoTime = video.currentTime;
      return start.apply(this, args);
    };
    const stop = MediaRecorder.prototype.stop;
    MediaRecorder.prototype.stop = function (...args: Parameters<MediaRecorder['stop']>) {
      trace.recorderStopAt = performance.now();
      trace.recorderStopVideoTime = video.currentTime;
      return stop.apply(this, args);
    };
  });

  await page.getByRole('button', { name: 'Record', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Preparing recording…', exact: true })).toBeVisible();
  await page.waitForTimeout(350);
  const beforeRealPlayback = await page.evaluate(() => {
    const trace = (window as unknown as Window & { __delayedCaptureTrace: { recorderStartAt: number | null; requestedAt: number | null } }).__delayedCaptureTrace;
    return { ...trace, videoTime: document.querySelector('video')?.currentTime ?? null };
  });
  expect(beforeRealPlayback.requestedAt).not.toBeNull();
  expect(beforeRealPlayback.recorderStartAt).toBeNull();
  expect(beforeRealPlayback.videoTime).not.toBeNull();
  expect(Math.abs((beforeRealPlayback.videoTime ?? 0) - preparedWindow.startMs / 1000)).toBeLessThanOrEqual(0.05);
  await page.screenshot({ path: path.join(evidenceDirectory, 'delayed-source-preparing.png') });

  const candidate = await waitForSavedCandidate(page, 'A');
  const trace = await page.evaluate(() => (window as unknown as Window & { __delayedCaptureTrace: Record<string, number | null> }).__delayedCaptureTrace);
  const expectedDuration = (preparedWindow.endMs - preparedWindow.startMs) / 1000;
  expect(trace.nativePlayAt).toBeGreaterThan(trace.requestedAt ?? 0);
  expect((trace.nativePlayAt ?? 0) - (trace.requestedAt ?? 0)).toBeGreaterThanOrEqual(1_150);
  expect(trace.playingAt).toBeGreaterThanOrEqual(trace.nativePlayAt ?? 0);
  expect(trace.recorderStartAt).toBeGreaterThanOrEqual(trace.playingAt ?? 0);
  expect(Math.abs((trace.recorderStartVideoTime ?? 0) - (trace.playingVideoTime ?? 0))).toBeLessThanOrEqual(0.05);
  expect((trace.playingVideoTime ?? 0)).toBeGreaterThanOrEqual(preparedWindow.startMs / 1000 - 0.05);
  expect((trace.recorderStopVideoTime ?? 0)).toBeGreaterThanOrEqual(preparedWindow.endMs / 1000 - 0.15);
  expect(Math.abs(((trace.recorderStopVideoTime ?? 0) - (trace.recorderStartVideoTime ?? 0)) - expectedDuration)).toBeLessThanOrEqual(0.2);
  expect(candidate?.blobSize).toBeGreaterThan(0);
  expect(candidate?.sha256).toMatch(/^[a-f0-9]{64}$/);
  expect((candidate?.probe as { decodedFrames?: number }).decodedFrames).toBeGreaterThan(0);
  expect(await evidenceCounters(page)).toEqual({ getUserMediaCalls: 1, recorderStarts: 1 });
  await page.screenshot({ path: path.join(evidenceDirectory, 'delayed-source-candidate.png') });
  await writeFile(path.join(evidenceDirectory, 'delayed-source-native-capture.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    input: 'Chrome browser fake audio input; not a physical microphone',
    sourcePlayDelayMs: 1_200,
    preparedWindow,
    expectedDuration,
    beforeRealPlayback,
    nativeTrace: trace,
    persistedCandidate: candidate,
    apiCounters: await evidenceCounters(page),
  }, null, 2), 'utf8');
});

for (const layout of ['A', 'B'] as const) {
  test(`Layout ${layout} records real browser fake input, recovers the candidate, and completes the accepted snapshot`, async ({ page, browser }) => {
    test.setTimeout(60_000);
    await page.setViewportSize({ width: 1440, height: 900 });
    await instrumentNativeMedia(page);
    await page.goto(`/projects/sintel-prepared/record?layout=${layout}&locale=en`);
    if (layout === 'A') await expect(page.getByRole('heading', { name: 'Sintel · The Search' })).toBeVisible();
    else {
      await expect(page.locator('.record-header h1')).toBeVisible();
      await expect(page.locator('.position-dots')).toBeVisible();
      await expect(page.locator('.record-header__line-count')).toHaveText('Line 1 / 3');
    }
    await expect.poll(() => page.locator('video').evaluate((video: HTMLVideoElement) =>
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0), { timeout: 15_000 }).toBe(true);
    await expect(page.locator('.waveform-row')).toHaveAttribute('data-source-waveform', 'decoded');
    await page.evaluate(() => document.fonts.ready);
    await expect(page.getByRole('button', { name: 'Exit', exact: true })).toBeInViewport();
    if (layout === 'A') {
      await expect(page.getByRole('heading', { name: 'Sintel · The Search' })).toBeInViewport();
      await expect(page.getByLabel('Current line')).toBeInViewport();
    } else {
      await expect(page.locator('.record-header__line-count')).toBeInViewport();
      await expect(page.getByLabel('Current line')).toBeInViewport();
    }
    const dialogue = page.locator('.dialogue-copy p');
    const englishDialogue = await dialogue.textContent();
    await setRecordLocale(page, 'ru');
    await expect(dialogue).toContainText(/[\u0400-\u04FF]/);
    const russianDialogue = await dialogue.textContent();
    expect(russianDialogue).not.toBe(englishDialogue);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-russian.png`) });
    await setRecordLocale(page, 'en');
    await expect(dialogue).toHaveText(englishDialogue ?? '');
    await expect(page.locator('.record-header .locale-control')).toHaveCount(0);
    await expect(page.locator('.record-header .lucide-log-out')).toHaveCount(1);
    await expect(page.locator('.record-controls button').filter({ hasText: 'Previous' }).locator('.lucide-chevron-left')).toHaveCount(1);
    const initialButton = page.getByRole('button', { name: 'Record', exact: true });
    await expect(initialButton).toBeEnabled();
    expect(await evidenceCounters(page)).toEqual({ getUserMediaCalls: 0, recorderStarts: 0 });
    const headerEvidence = await page.evaluate(() => {
      const inspect = (selector: string) => {
        const element = document.querySelector(selector);
        if (!element) return null;
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return {
          text: element.textContent?.trim() ?? '',
          x: rect.x, y: rect.y, width: rect.width, height: rect.height,
          color: style.color, opacity: style.opacity, visibility: style.visibility, display: style.display,
        };
      };
      return {
        exit: inspect('.exit-link'), title: inspect('.record-header h1'),
        locale: inspect('.locale-control'), dots: inspect('.position-dots'),
        mabryLoaded: document.fonts.check('400 26px "Mabry Pro"'),
        dialogueFont: getComputedStyle(document.querySelector('.dialogue-copy p')!).fontFamily,
        scrollY: window.scrollY,
      };
    });
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-ready.png`) });

    const viewport = await page.locator('.media-viewport').boundingBox();
    const wave = await page.locator('.waveform-stack').boundingBox();
    const controls = await page.locator('.record-controls').boundingBox();
    expect(viewport).not.toBeNull();
    expect(wave).not.toBeNull();
    expect(controls).not.toBeNull();
    if (viewport) {
      const center = viewport.x + viewport.width / 2;
      const visibleCenter = await page.evaluate(() => document.documentElement.clientWidth / 2);
      expect(Math.abs(center - visibleCenter)).toBeLessThanOrEqual(1);
      const exit = await page.getByRole('button', { name: 'Exit', exact: true }).boundingBox();
      expect(Math.abs((exit?.x ?? -999) - viewport.x)).toBeLessThanOrEqual(1);
    }
    if (viewport && layout === 'A') {
      const panel = await page.locator('.record-panel').boundingBox();
      expect(panel?.width).toBe(272);
      expect(panel!.x - (viewport.x + viewport.width)).toBeGreaterThanOrEqual(23);
      expect(viewport.x).toBeGreaterThanOrEqual(32);
    }
    if (wave && controls && layout === 'B') expect(controls.y - (wave.y + wave.height)).toBeGreaterThanOrEqual(23);

    await page.getByRole('button', { name: 'Original', exact: true }).click();
    await expect.poll(() => page.locator('video').evaluate((video: HTMLVideoElement) => video.currentTime)).toBeGreaterThan(0.1);
    await page.getByRole('button', { name: 'Pause', exact: true }).click();
    await page.getByRole('button', { name: 'Resume', exact: true }).click();
    await expect.poll(async () => (await evidenceCounters(page)).recorderStarts).toBe(0);

    await page.getByRole('button', { name: 'Record', exact: true }).click();
    await expect.poll(async () => (await evidenceCounters(page)).recorderStarts).toBe(1);
    const recordingNotice = layout === 'A' ? page.locator('.record-panel .notice') : page.locator('.record-status--b .notice');
    await expect(recordingNotice).toContainText('Recording the full prepared window. It will stop automatically.');
    await expect(page.getByRole('button', { name: /Countdown|Stop recording|Pause recording/i })).toHaveCount(0);
    await waitForSavedCandidate(page, layout);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-candidate.png`) });

    const audio = page.locator('audio');
    await page.getByRole('button', { name: 'Your take', exact: true }).click();
    await expect.poll(() => audio.evaluate((element: HTMLAudioElement) => element.currentTime)).toBeGreaterThan(0.05);
    expect(await audio.getAttribute('src')).toContain('blob:');

    if (layout === 'A') {
      await page.getByRole('button', { name: 'Exit', exact: true }).click();
      await expect(page.getByRole('dialog')).toBeVisible();
      await page.screenshot({ path: path.join(evidenceDirectory, 'layout-a-1440x900-candidate-guard.png') });
      await page.getByRole('dialog').getByRole('button', { name: 'Stay here', exact: true }).last().click();
      await expect(page.getByRole('dialog')).toBeHidden();
      const beforeReload = await readIndexedDb(page);
      expect(Object.values(beforeReload.project?.acceptedByTurn as Record<string, string> ?? {})).toHaveLength(0);
      const countersBeforeReload = await evidenceCounters(page);
      await page.reload();
      await expect(page.getByRole('button', { name: 'Your take', exact: true })).toBeEnabled();
      expect(await evidenceCounters(page)).toEqual(countersBeforeReload);
      await page.screenshot({ path: path.join(evidenceDirectory, 'layout-a-1440x900-reloaded-candidate.png') });
    }

    await page.setViewportSize({ width: 390, height: 667 });
    if (layout === 'A') await expect(page.getByRole('heading', { name: 'Sintel · The Search' })).toBeVisible();
    else {
      await expect(page.locator('.record-header__line-count')).toBeVisible();
      await expect(page.getByRole('heading', { name: 'Sintel · The Search' })).toBeVisible();
      await expect(page.getByLabel('Current line')).toBeVisible();
    }
    const horizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
    expect(horizontalOverflow).toBe(false);
    await setRecordLocale(page, 'ru');
    await expect(dialogue).toContainText(/[\u0400-\u04FF]/);
    expect(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth)).toBe(false);
    const targetSize = await page.locator('.record-action').boundingBox();
    expect(targetSize?.height).toBeGreaterThanOrEqual(48);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-390x667-russian.png`) });
    await setRecordLocale(page, 'en');
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-390x667-ready.png`) });
    await page.setViewportSize({ width: 1440, height: 900 });

    await page.getByRole('button', { name: 'Next', exact: true }).click();
    await expect(page).toHaveURL(new RegExp(`turn=sintel-turn-2`));
    await setRecordLocale(page, 'ru');
    await expect(dialogue).toContainText(/[\u0400-\u04FF]/);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-turn-2-russian.png`) });
    await setRecordLocale(page, 'en');
    await recordCurrentWindow(page, layout);
    await page.getByRole('button', { name: 'Next', exact: true }).click();
    await expect(page).toHaveURL(new RegExp(`turn=sintel-turn-3`));
    await setRecordLocale(page, 'ru');
    await expect(dialogue).toContainText(/[\u0400-\u04FF]/);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-turn-3-russian.png`) });
    await setRecordLocale(page, 'en');
    await recordCurrentWindow(page, layout);

    const media = await readIndexedDb(page);
    expect(media.media.filter((candidate) => candidate.purpose === 'recording')).toHaveLength(3);
    expect(Object.values(media.project?.acceptedByTurn as Record<string, string> ?? {})).toHaveLength(2);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-final-candidate.png`) });

    if (layout === 'A') {
      await page.route('**/media/example-dub.mp4', (route) => route.fulfill({ status: 503, body: 'fixture unavailable for the first attempts' }));
      await page.setViewportSize({ width: 390, height: 667 });
      await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
      expect(await page.evaluate(() => window.scrollY)).toBeGreaterThan(0);
      await page.getByRole('button', { name: 'Next', exact: true }).evaluate((button: HTMLButtonElement) => button.click());
      await expect(page).toHaveURL(/\/result\?layout=A&snapshot=/);
      await expect(page.getByRole('heading', { name: 'Your result' })).toBeInViewport();
      await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(0);
      await expect.poll(() => page.evaluate(() => document.activeElement?.tagName)).toBe('H1');
      await page.setViewportSize({ width: 1440, height: 900 });
    } else {
      await page.getByRole('button', { name: 'Exit', exact: true }).click();
      await expect(page.getByRole('dialog')).toBeVisible();
      await page.getByRole('button', { name: 'Save and leave', exact: true }).click();
      await expect(page).toHaveURL(/\/projects\?returnProject=sintel-prepared&returnLayout=B&returnFocus=exit/);
      await page.getByTestId('return-to-saved-record').click();
      await expect(page).toHaveURL(/\/projects\/sintel-prepared\/record\?layout=B&turn=sintel-turn-3/);
      await expect(page.locator('[data-logical-focus="exit"]')).toBeFocused();
    }

    let finalDatabase = await readIndexedDb(page);
    expect(finalDatabase.project?.initialResultSnapshotId).toBeTruthy();
    expect(finalDatabase.snapshots).toHaveLength(1);
    const snapshot = finalDatabase.snapshots[0] as { takes: unknown[]; authorization: string; contentSha256: string };
    expect(snapshot.authorization).toBe('initial-completion');
    expect(snapshot.takes).toHaveLength(3);
    expect(snapshot.contentSha256).toMatch(/^[a-f0-9]{64}$/);

    if (layout === 'B') {
      const snapshotId = String(finalDatabase.project?.latestResultSnapshotId ?? '');
      expect(snapshotId).toBeTruthy();
      await page.goto(`/projects/sintel-prepared/result?layout=B&snapshot=${encodeURIComponent(snapshotId)}`);
    }
    await expect(page.getByRole('heading', { name: 'Your result' })).toBeVisible();
    await expect(page.locator('.result-player__source-tabs button').filter({ hasText: 'My dub' })).toBeVisible();
    await expect(page.locator('.result-header h1')).toBeFocused();
    expect(await page.evaluate(() => window.scrollY)).toBe(0);
    expect(await page.locator('.result-header .lucide-log-out').count()).toBe(1);
    expect(await page.locator('.result-workspace__actions button').filter({ hasText: 'Return to recording' }).locator('.lucide-undo-2').count()).toBe(1);

    if (layout === 'A') {
      await expect(page.getByRole('button', { name: 'Retry assembly', exact: true })).toBeVisible();
      await expect(page.getByText('The result sample could not be loaded. Your accepted takes and previous result remain unchanged.')).toBeVisible();
      await page.screenshot({ path: path.join(evidenceDirectory, 'layout-a-result-fixture-unavailable.png') });
      await page.unroute('**/media/example-dub.mp4');
      await page.getByRole('button', { name: 'Retry assembly', exact: true }).click();
    }

    await expect(page.getByText('Illustrative result sample available')).toBeVisible({ timeout: 15_000 });
    const resultVideo = page.getByTestId('result-video');
    await expect(resultVideo).toHaveAttribute('data-source', 'dub');
    await expect(resultVideo).toHaveAttribute('src', /^blob:/);
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.videoWidth > 0)).toBe(true);
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    const presentedGenerationId = await resultVideo.getAttribute('data-generation-id');
    expect(presentedGenerationId).toMatch(/^generation:/);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-result-ready.png`) });
    const normalResult = await page.evaluate(() => {
      const bounds = (selector: string) => {
        const element = document.querySelector(selector);
        if (!element) return null;
        const rect = element.getBoundingClientRect();
        return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, bottom: rect.bottom };
      };
      return {
        screen: bounds('.result-player__screen'),
        seek: bounds('.result-player__seek'),
        controls: bounds('.result-player__transport-row'),
      };
    });
    await writeFile(path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1440x900-result-metrics.json`), JSON.stringify(normalResult, null, 2), 'utf8');
    expect(Math.abs(normalResult.screen!.y - (layout === 'A' ? 108 : 104))).toBeLessThanOrEqual(1);
    expect(Math.abs(normalResult.screen!.width - 920)).toBeLessThanOrEqual(2);
    expect(normalResult.seek!.bottom).toBeLessThanOrEqual(normalResult.controls!.y + 1);
    await page.setViewportSize({ width: 1280, height: 600 });
    await expect.poll(() => page.evaluate(() => document.documentElement.scrollHeight <= window.innerHeight)).toBe(true);
    const shortResult = await page.evaluate(() => {
      const bounds = (selector: string) => {
        const element = document.querySelector(selector);
        if (!element) return null;
        const rect = element.getBoundingClientRect();
        return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, bottom: rect.bottom };
      };
      return {
        documentHeight: document.documentElement.scrollHeight,
        title: bounds('.result-header h1'),
        player: bounds('.result-player'),
        screen: bounds('.result-player__screen'),
        rail: bounds('.result-player__transport'),
        seek: bounds('.result-player__seek'),
        controls: bounds('.result-player__transport-row'),
        details: bounds('.result-workspace__details'),
        actions: bounds('.result-workspace__actions'),
      };
    });
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1280x600-result-ready.png`) });
    await writeFile(path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-1280x600-result-metrics.json`), JSON.stringify(shortResult, null, 2), 'utf8');
    expect(shortResult.documentHeight).toBeLessThanOrEqual(600);
    expect(shortResult.title?.y ?? -1).toBeGreaterThanOrEqual(0);
    expect(shortResult.title!.bottom).toBeLessThanOrEqual(600);
    const shortTarget = layout === 'A' ? { y: 88, width: 548 } : { y: 80, width: 562 };
    expect(Math.abs(shortResult.screen!.y - shortTarget.y)).toBeLessThanOrEqual(1);
    expect(Math.abs(shortResult.screen!.width - shortTarget.width)).toBeLessThanOrEqual(4);
    expect(shortResult.seek!.bottom).toBeLessThanOrEqual(shortResult.controls!.y + 1);
    expect(shortResult.actions!.height).toBeGreaterThanOrEqual(88);
    expect(shortResult.actions!.bottom).toBeLessThanOrEqual(600);
    await page.setViewportSize({ width: 1440, height: 900 });

    const originalSource = page.locator('.result-player__source-tabs button').filter({ hasText: 'Original' });
    const dubSource = page.locator('.result-player__source-tabs button').filter({ hasText: 'My dub' });
    await expect(page.locator('.result-player__source-tabs')).toHaveAttribute('role', 'group');
    await expect(originalSource).toHaveAttribute('aria-pressed', 'false');
    await originalSource.focus();
    await page.keyboard.press('Space');
    await expect(originalSource).toHaveAttribute('aria-pressed', 'true');
    await expect(resultVideo).toHaveAttribute('data-source', 'original');
    await page.getByRole('button', { name: 'Play', exact: true }).click();
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.currentTime)).toBeGreaterThan(0.2);
    const switchTime = await resultVideo.evaluate((video: HTMLVideoElement) => video.currentTime);
    await dubSource.click();
    await expect(dubSource).toHaveAttribute('aria-pressed', 'true');
    await expect(originalSource).toHaveAttribute('aria-pressed', 'false');
    await expect(resultVideo).toHaveAttribute('data-generation-id', presentedGenerationId ?? '');
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => !video.paused)).toBe(true);
    await expect.poll(async () => Math.abs(await resultVideo.evaluate((video: HTMLVideoElement) => video.currentTime) - switchTime))
      .toBeLessThan(1.5);

    const resultSeek = page.locator('.result-player__seek');
    await resultSeek.focus();
    await page.keyboard.down('ArrowRight');
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    await page.keyboard.up('ArrowRight');
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => !video.paused)).toBe(true);
    const afterKeyboardRelease = await resultVideo.evaluate((video: HTMLVideoElement) => video.currentTime);
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.currentTime)).toBeGreaterThan(afterKeyboardRelease);

    await resultVideo.evaluate((video: HTMLVideoElement) => video.pause());
    await resultSeek.dispatchEvent('pointerdown');
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    await resultSeek.dispatchEvent('pointercancel');
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    await page.getByRole('button', { name: 'Play', exact: true }).click();
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => !video.paused)).toBe(true);
    await resultSeek.dispatchEvent('pointerdown');
    await resultSeek.evaluate((input: HTMLInputElement) => input.blur());
    await expect.poll(() => resultVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);

    const currentGenerationBeforeDownload = await resultVideo.getAttribute('data-generation-id');
    await originalSource.click();
    await expect(resultVideo).toHaveAttribute('data-source', 'original');
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      page.getByRole('button', { name: 'Download My dub', exact: true }).click(),
    ]);
    const downloadPath = await download.path();
    expect(download.suggestedFilename()).toBe('example-dub.mp4');
    expect(downloadPath).not.toBeNull();
    const downloadedBytes = await readFile(downloadPath!);
    const expectedFixtureBytes = await readFile(path.resolve(process.cwd(), 'public', 'media', 'example-dub.mp4'));
    const downloadedSha256 = createHash('sha256').update(downloadedBytes).digest('hex');
    expect(downloadedBytes.equals(expectedFixtureBytes)).toBe(true);

    const resultDatabase = await page.evaluate(async () => {
      const database = await new Promise<IDBDatabase>((resolve, reject) => {
        const request = indexedDB.open('dubbed-core-local-v1');
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      const read = <T>(name: string) => new Promise<T>((resolve, reject) => {
        const request = database.transaction(name, 'readonly').objectStore(name).getAll();
        request.onsuccess = () => resolve(request.result as T);
        request.onerror = () => reject(request.error);
      });
      const jobs = await read<Array<{ id: string; snapshotId: string; status: string; productRendered: boolean; assembledFromAcceptedTakes: boolean }>>('resultJobs');
      const resultMedia = await read<Array<{ id: string; filename: string; byteSize: number; sha256: string; blob: Blob }>>('resultMedia');
      database.close();
      return {
        jobs: jobs.map(({ id, snapshotId, status, productRendered, assembledFromAcceptedTakes }) => ({ id, snapshotId, status, productRendered, assembledFromAcceptedTakes })),
        media: resultMedia.map(({ id, filename, byteSize, sha256, blob }) => ({ id, filename, byteSize, sha256, blobSize: blob.size })),
      };
    });
    expect(resultDatabase.jobs).toContainEqual(expect.objectContaining({
      id: currentGenerationBeforeDownload,
      status: 'ready',
      productRendered: false,
      assembledFromAcceptedTakes: false,
    }));
    expect(resultDatabase.media).toContainEqual(expect.objectContaining({
      id: currentGenerationBeforeDownload,
      filename: 'example-dub.mp4',
      byteSize: expectedFixtureBytes.byteLength,
      blobSize: expectedFixtureBytes.byteLength,
      sha256: downloadedSha256,
    }));

    await page.setViewportSize({ width: 390, height: 844 });
    await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    expect(await page.getByRole('button', { name: 'Download My dub', exact: true }).boundingBox().then((box) => box?.height ?? 0)).toBeGreaterThanOrEqual(48);
    const mobileTargets = await page.evaluate(() => Array.from(document.querySelectorAll('.result-player__seek, .result-player__volume input'), (element) => {
      const bounds = element.getBoundingClientRect();
      return { label: element.getAttribute('aria-label'), height: bounds.height, width: bounds.width };
    }));
    expect(mobileTargets).toHaveLength(2);
    expect(mobileTargets.every((target) => target.height >= 48)).toBe(true);
    await expect(page.locator('.result-player__seek')).toBeEnabled();
    await expect(page.locator('.result-player__volume input')).toBeEnabled();
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-390x844-result-ready.png`), fullPage: true });

    finalDatabase = await readIndexedDb(page);
    const nativeEvidence = await evidenceCounters(page);
    expect(nativeEvidence.getUserMediaCalls).toBeGreaterThan(0);
    expect(nativeEvidence.recorderStarts).toBeGreaterThan(0);
    await writeFile(path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-browser-evidence.json`), JSON.stringify({
      date: new Date().toISOString(),
      layout,
      browser: `Chrome ${browser.version()}`,
      input: 'Chrome browser fake audio input; not a physical microphone',
      nativeApiEvidence: nativeEvidence,
      initialHeader: headerEvidence,
      project: finalDatabase.project,
      captures: finalDatabase.media.filter((candidate) => candidate.purpose === 'recording'),
      operations: finalDatabase.operations,
      snapshots: finalDatabase.snapshots,
      result: {
        generationId: currentGenerationBeforeDownload,
        currentComparisonAtDownload: 'original',
        downloadFilename: download.suggestedFilename(),
        downloadSha256: downloadedSha256,
        exactFixtureBytesMatch: downloadedBytes.equals(expectedFixtureBytes),
        fixtureProvenance: 'Fixed illustrative sample; productRendered=false; assembledFromAcceptedTakes=false',
        jobs: resultDatabase.jobs,
        media: resultDatabase.media,
      },
      assertions: ['No getUserMedia or MediaRecorder before explicit Record', 'video moved during each native recording', 'captured Blob persisted and hashed', 'accepted snapshot includes exact three recorded candidates', 'native controls remained locked during capture', 'Result generation consumed the authorized immutable snapshot', 'player served exact fixture bytes and remained paused on entry', 'source switch preserved playhead and play intent', 'download from Original preview pinned the presented My dub generation', 'downloaded bytes match the persisted fixture hash', 'mobile Result has no horizontal overflow and a 48px download target'],
    }, null, 2), 'utf8');

    const resultRoute = page.url();
    await page.getByRole('button', { name: 'Return to recording', exact: true }).click();
    await expect(page).toHaveURL(new RegExp(`/projects/sintel-prepared/record\\?layout=${layout}&turn=sintel-turn-1`));
    const returnedRecordVideo = page.locator('.media-viewport video');
    await expect.poll(() => returnedRecordVideo.evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    await page.screenshot({ path: path.join(evidenceDirectory, `layout-${layout.toLowerCase()}-result-return-first-turn.png`) });
    await page.goto(resultRoute);
    await expect(page.getByRole('heading', { name: 'Your result' })).toBeVisible();
    await expect.poll(() => page.getByTestId('result-video').evaluate((video: HTMLVideoElement) => video.paused)).toBe(true);
    await expect(page.getByTestId('result-video')).toHaveAttribute('data-source', 'dub');

    if (layout === 'A') {
      const leavingVideo = await page.getByTestId('result-video').evaluateHandle((video) => video);
      await page.getByRole('button', { name: 'Play', exact: true }).click();
      await expect.poll(() => page.getByTestId('result-video').evaluate((video: HTMLVideoElement) => !video.paused)).toBe(true);
      await page.getByRole('button', { name: 'Exit', exact: true }).click();
      await expect(page).toHaveURL(/\/projects\?.*returnFocus=exit/);
      expect(await leavingVideo.evaluate((video) => (video as HTMLVideoElement).paused)).toBe(true);
      await page.getByTestId('return-to-saved-record').click();
      await expect(page).toHaveURL(/returnFocus=exit/);
      await expect(page.locator('[data-logical-focus="exit"]')).toBeFocused();
    }

    if (layout === 'B') {
      await page.evaluate(async () => {
        type ResultStore = {
          readGenerationMedia(scope: unknown, id: unknown): Promise<unknown>;
          loadPreparedProject(scope: unknown): Promise<{ revision: number } | null>;
          tombstoneProject(scope: unknown, revision: number, operation: string): Promise<number>;
        };
        type Fiber = { child?: unknown; sibling?: unknown; memoizedProps?: unknown };
        const root = document.getElementById('root') as (HTMLElement & Record<string, unknown>) | null;
        if (!root) throw new Error('The React root is unavailable.');
        const rootKey = Object.keys(root).find((key) => key.startsWith('__reactContainer$'));
        if (!rootKey) throw new Error('The React root fiber is unavailable.');
        const pending: unknown[] = [root[rootKey]];
        let store: ResultStore | null = null;
        while (pending.length > 0) {
          const fiber = pending.pop() as Fiber | null;
          if (!fiber) continue;
          const props = fiber.memoizedProps as { services?: { results?: ResultStore } } | null;
          if (props?.services?.results) store = props.services.results;
          if (fiber.child) pending.push(fiber.child);
          if (fiber.sibling) pending.push(fiber.sibling);
        }
        if (!store) throw new Error('The active typed ResultPort was not found in the services provider.');
        const originalRead = store.readGenerationMedia.bind(store);
        const target = window as Window & { __deletedBeforeGenerationDelivery?: boolean };
        store.readGenerationMedia = async (scope, id) => {
          const payload = await originalRead(scope, id);
          const project = await store.loadPreparedProject(scope);
          if (!project) throw new Error('The prepared project disappeared before the tombstone seam.');
          await store.tombstoneProject(scope, project.revision, `review-delete:${crypto.randomUUID()}`);
          target.__deletedBeforeGenerationDelivery = true;
          return payload;
        };
      });
      let downloadEvents = 0;
      page.on('download', () => { downloadEvents += 1; });
      await page.getByRole('button', { name: 'Download My dub', exact: true }).click();
      await expect(page.locator('[data-testid="deleted-project-boundary"]')).toBeVisible();
      expect(await page.evaluate(() => (window as Window & { __deletedBeforeGenerationDelivery?: boolean }).__deletedBeforeGenerationDelivery)).toBe(true);
      expect(downloadEvents).toBe(0);
      await expect(page.getByTestId('result-player')).toHaveCount(0);
      await page.screenshot({ path: path.join(evidenceDirectory, 'B-download-tombstoned-before-delivery.png'), fullPage: true });
    }
  });
}

test('completed revision stays in Record after Next and needs explicit To result authorization', async ({ page, browser }) => {
  test.setTimeout(75_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A&locale=en');
  await expect.poll(() => page.locator('video').evaluate((video: HTMLVideoElement) =>
    video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0), { timeout: 15_000 }).toBe(true);
  await expect(page.locator('.waveform-row')).toHaveAttribute('data-source-waveform', 'decoded');
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();

  for (const turn of [1, 2, 3]) {
    await recordCurrentWindow(page, 'A');
    await page.getByRole('button', { name: 'Next', exact: true }).click();
    if (turn < 3) await expect(page).toHaveURL(new RegExp(`turn=sintel-turn-${turn + 1}`));
  }

  await expect(page).toHaveURL(/\/result\?layout=A&snapshot=/);
  await expect(page.getByText('Illustrative result sample available')).toBeVisible({ timeout: 15_000 });
  const initial = await readIndexedDb(page);
  const initialSnapshotId = String(initial.project?.initialResultSnapshotId ?? '');
  expect(initialSnapshotId).toBeTruthy();
  await page.screenshot({ path: path.join(evidenceDirectory, 'phase4-initial-result-before-revision.png'), fullPage: true });

  await page.getByRole('button', { name: 'Return to recording', exact: true }).click();
  await expect(page).toHaveURL(/\/record\?layout=A&turn=sintel-turn-1/);
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  const returnLocks = await page.evaluate(() => (window as unknown as Window & {
    __lockEvidence: { requests: string[]; callbacks: Array<'acquired' | 'null'> };
  }).__lockEvidence);
  expect(returnLocks.requests).toHaveLength(2);
  expect(returnLocks.callbacks).toEqual(['acquired', 'acquired']);
  await recordCurrentWindow(page, 'A');
  await page.getByRole('button', { name: 'Next', exact: true }).click();
  await expect(page).toHaveURL(/\/record\?layout=A&turn=sintel-turn-1/);
  await expect(page.getByRole('button', { name: 'To result', exact: true })).toBeVisible();
  await expect(page).not.toHaveURL(/\/result/);
  const afterReplacementNext = page.url();

  await page.goto('/projects/sintel-prepared/record?layout=A&turn=sintel-turn-3&locale=en');
  await expect(page.getByRole('button', { name: 'To result', exact: true })).toBeVisible();
  await page.screenshot({ path: path.join(evidenceDirectory, 'phase4-completed-revision-last-turn.png'), fullPage: true });
  await page.getByRole('button', { name: 'To result', exact: true }).click();
  await expect(page).toHaveURL(/\/result\?layout=A&snapshot=/);
  const presentedVideo = page.getByTestId('result-video');
  await expect.poll(() => presentedVideo.evaluate((video: HTMLVideoElement) =>
    video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0
      && video.currentSrc.startsWith('blob:')), { timeout: 15_000 }).toBe(true);
  await expect(page.getByText('Illustrative result sample available')).toBeVisible();

  const revised = await readIndexedDb(page);
  expect(revised.snapshots).toHaveLength(2);
  const originalSnapshot = revised.snapshots.find((snapshot) => snapshot.id === initialSnapshotId);
  expect((originalSnapshot as { authorization?: string } | undefined)?.authorization).toBe('initial-completion');
  const explicitSnapshot = revised.snapshots.find((snapshot) => snapshot.authorization === 'explicit-completed-revision') as
    { id: string; authorization: string; takes: unknown[] } | undefined;
  expect(explicitSnapshot).toBeDefined();
  if (!explicitSnapshot) throw new Error('The explicit completed revision snapshot was not persisted.');
  expect(explicitSnapshot.authorization).toBe('explicit-completed-revision');
  expect(explicitSnapshot.id).not.toBe(initialSnapshotId);
  expect(explicitSnapshot.takes).toHaveLength(3);
  const presentedMedia = await presentedVideo.evaluate((video: HTMLVideoElement) => ({
    source: video.dataset.source,
    generationId: video.dataset.generationId,
    currentSrc: video.currentSrc,
    readyState: video.readyState,
    currentTime: video.currentTime,
    duration: Number.isFinite(video.duration) ? video.duration : null,
    durationMetadata: video.duration === Infinity ? 'unknown-until-end' : Number.isNaN(video.duration) ? 'unavailable' : 'finite',
    width: video.videoWidth,
    height: video.videoHeight,
    paused: video.paused,
  }));
  expect(presentedMedia.source).toBe('dub');
  await page.screenshot({ path: path.join(evidenceDirectory, 'phase4-explicit-revision-result.png'), fullPage: true });
  await writeFile(path.join(evidenceDirectory, 'phase4-explicit-revision-browser-evidence.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    nativeInput: 'Chrome fake media input; not a physical microphone',
    initialSnapshotId,
    revisedSnapshot: explicitSnapshot,
    presentedMedia,
    captureGrantLifecycle: returnLocks,
    afterReplacementNext,
    automaticResultNavigationAfterReplacement: false,
    explicitToResultClicked: true,
  }, null, 2));
});

test('a second open tab cannot capture or accept while the first tab holds the local project grant', async ({ page }) => {
  await page.goto('/projects/sintel-prepared/record?layout=A');
  await expect(page.getByRole('button', { name: 'Record', exact: true })).toBeEnabled();
  const secondPage = await page.context().newPage();
  await secondPage.goto('/projects/sintel-prepared/record?layout=B');
  await expect(secondPage.getByRole('button', { name: 'Record', exact: true })).toBeDisabled();
  await expect(secondPage.getByRole('alert')).toContainText('Another open tab currently holds this project’s local recording access.');
  await secondPage.close();
});

test('denied microphone permission is contextual and does not start MediaRecorder', async ({ page, browser }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.addInitScript(() => {
    (window as Window & { __denyMicrophone?: boolean }).__denyMicrophone = true;
  });
  await instrumentNativeMedia(page);
  await page.goto('/projects/sintel-prepared/record?layout=A');
  await expect(page.getByRole('heading', { name: 'Sintel · The Search' })).toBeVisible();

  await page.getByRole('button', { name: 'Record', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Settings', exact: true })).toBeVisible();
  await expect(page.locator('.record-panel .notice')).toContainText('Microphone access was denied or interrupted. Recording did not begin');
  expect(await evidenceCounters(page)).toEqual({ getUserMediaCalls: 1, recorderStarts: 0 });
  const database = await readIndexedDb(page);
  expect(database.media.filter((candidate) => candidate.purpose === 'recording')).toHaveLength(0);
  const toast = page.locator('.recovery-toast');
  await expect(toast).toBeVisible();
  expect(await toast.getAttribute('aria-hidden')).toBe('true');
  expect(await toast.getByRole('button').count()).toBe(0);
  await page.waitForTimeout(1000);
  await expect(toast).toBeVisible();
  await page.waitForTimeout(6500);
  const toastBounds = await toast.boundingBox();
  expect(toastBounds).not.toBeNull();
  await page.mouse.move(toastBounds!.x + toastBounds!.width / 2, toastBounds!.y + toastBounds!.height / 2);
  await page.waitForTimeout(950);
  await expect(toast).toBeVisible();
  await page.mouse.move(20, 20);
  await expect(toast).toHaveCount(0, { timeout: 1500 });
  await expect(page.locator('.record-panel .notice')).toContainText('Microphone access was denied or interrupted. Recording did not begin');

  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload();
  await page.getByRole('button', { name: 'Record', exact: true }).click();
  await expect(page.locator('.recovery-toast')).toBeVisible();
  const reducedMotionTransitionSeconds = await page.locator('.recovery-toast').evaluate((element) =>
    Number.parseFloat(getComputedStyle(element).transitionDuration.split(',')[0] ?? '1'));
  expect(reducedMotionTransitionSeconds).toBeLessThan(0.001);
  await page.mouse.wheel(0, 100);
  await expect(page.locator('.recovery-toast')).toHaveCount(0, { timeout: 1_000 });
  await expect(page.locator('.record-panel .notice')).toContainText('Microphone access was denied or interrupted. Recording did not begin');
  await page.getByRole('button', { name: 'Settings', exact: true }).click();
  await expect(page).toHaveURL(/\/settings\/microphone\?/);
  await page.getByTestId('return-to-saved-record').click();
  await expect(page).toHaveURL(/returnFocus=settings/);
  await expect(page.locator('[data-logical-focus="settings"]')).toBeFocused();
  await writeFile(path.join(evidenceDirectory, 'permission-denied-browser-evidence.json'), JSON.stringify({
    date: new Date().toISOString(),
    browser: `Chrome ${browser.version()}`,
    permission: 'test harness rejected getUserMedia with NotAllowedError; browser permission UI was not exercised',
    nativeApiEvidence: await evidenceCounters(page),
    savedRecordingCount: database.media.filter((candidate) => candidate.purpose === 'recording').length,
    settingsBoundaryAvailable: await page.getByRole('button', { name: 'Settings', exact: true }).isVisible(),
    settingsBoundaryReturnFocus: await page.locator('[data-logical-focus="settings"]').evaluate((element) => element === document.activeElement),
    recoveryToast: 'message only and aria-hidden; 8 second read interval; deliberate hover pause; reduced motion; manual wheel dismissal; durable error retained',
  }, null, 2), 'utf8');
});
